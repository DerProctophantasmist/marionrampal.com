[#### Let the Wind Blow](lyrics/Let the Wind Blow.md)  
[#### Savage](lyrics/Savage.md)  
[#### 5PM Song](lyrics/5 pm song.md)  
[#### The Perfect Husband](lyrics/The Perfect Husband.md)  
[#### Chanson de marin](lyrics/Chanson de marin.md)  
[#### The Heart](lyrics/The Heart.md)  
[#### Go for It](lyrics/Go for It.md)  
[#### Visitation of the Bayou Maharajah](lyrics/Visitation of the Bayou Maharajah.md)  
[#### À la mer](lyrics/A la mer.md)  

*Paroles et musiques de Marion Rampal, Éditions capt'n music*




**For Marion Rampal MAIN BLUE**  

MANAGEMENT & CONCERTS :   
François Peyratout   
+33 620 761010  
fr.peyratout *at* nemomusic.com  
http://www.nemomusic.com  

MEDIAS :  
Arielle Berthoud  
+ 33 6 09 70 72 18  
arielle.berthoud *at* noos.fr  
http://arielleberthoud.com  

**For other projets and collaborations:**  

contact *at* marionrampal.com

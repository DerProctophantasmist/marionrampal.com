



**Marion Rampal MAIN BLUE, TEXO & le secret**

MANAGEMENT & CONCERTS :  
FranĂ§ois Peyratout   
+33 620 761010  
fr.peyratout *at* nemomusic.com  
http://www.nemomusic.com  

MEDIAS :  
Arielle Berthoud  
00 33 (0)6 09 70 72 18  
arielle.berthoud *at* noos.fr  
http://arielleberthoud.com  

**Autres projets et collaborations:**  

contact *at* marionrampal.com

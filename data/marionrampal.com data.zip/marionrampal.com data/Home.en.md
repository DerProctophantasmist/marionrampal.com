## *OUT on October 18th 2019*
<div style="margin: 0" class="force-float-images-left clearfix text-center">
![couv le secret](images/couv le secret.jpeg)
__Marion RAMPAL: voice  
Pierre-François BLANCHARD: piano__  
*featuring*  
__Archie Shepp: tenor saxophone, voice  
Raúl Barboza: accordion  

*ArtOvations / l’Autre Distribution  
Recorded at Studio de Meudon by Alban Moraud*__
</div>
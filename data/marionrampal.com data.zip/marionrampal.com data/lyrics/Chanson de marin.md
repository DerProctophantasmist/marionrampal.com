#### Chanson de marin

Oh Capitaine,  
Ne pleure pas  
Car ta sirène  
Te reviendra  
Et dans ton rêve  
Te chantera :
“C’est pour de bon
C’est pour de bon”  

T’avais eu d’elle  
Qu’un aperçu  
T’avais eu d’elle  
Qu’un p’tit baiser  
Sur les grandes mers  
Tu as tant vogué  
Tu as oublié  
Tu as oublié  

A bord, à rive   
Hissant ta voile   
Et les yeux loin posés devant  
T’es fatigué  
T’es abrasé le palpitant  
L’a tout fondu  
Il a coulé, ton cœur  
S'est noyé, ton cœur  
L’est tombé  
L’a sombré en bas  
Plus bleu qu’au fond   
Dessous le fond  

Oh Capitaine  
Ne pleure plus  
Car ta sirène  
L’est là  
L’est revenue  
Et ton oreille  
L’a entendue  
C’est pour de bon  
C’est pour de bon  
___

 

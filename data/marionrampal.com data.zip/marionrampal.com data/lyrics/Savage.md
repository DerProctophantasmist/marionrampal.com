#### Savage

Toi qui t’etais tapi au creux de ma chanson,  
C'est dans le fond de l’eau que nous nous reverrons.  

Toi qui m’a bien souri quand la larme a coulé,  
Toi le Bien Averti, oh toi mon Bien Aimé.  

Toi qui t’etais barré du fond de ma maison,  
Les Fées me l’avaient dit: tu serais bel et bon.  

Toi qui m’avais gardée en ton beau Palpitant,  
Toujours je t’aimerai, Jusqu’à la fin des temps.  


Lui  
Venu chez moi  
L’était beau beaucoup  
L’était mille époux comme  
L’était mien au fond des nuits d’amour  
roulé coulé là  
Ah si l’avais pu garder  
Mais s’en est allé  
L’est parti loin loin devant  
Jeter yeux et mains vers les lendemains  


Ah il m’en a fait  
Il m’en a fait  
Il m’en a trop fait  
___
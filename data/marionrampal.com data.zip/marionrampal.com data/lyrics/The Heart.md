#### The Heart

The Heart  
Is always a lonely something  
A hunter  
A knife  
A warm and naked beast  


The Heart  
Is somehow soloing on strings  
Butter knife or chainsaw  
The Heart it always hums free  


The Heart  
It’s got a core  
And that’s for sure  
It’s got fangs and teeth too  
And other things beyond a spelling  


(and everybody wants it out of gold  
 And everybody wants to rule its world)  


The Heart  
It stands alone  
And it dies alone  
And just when you think you’ve dug it’s clicking  
It decides to change its timing  


Cause EVERYBODY WANTS IT  
A LOVELY LOVE TO LOVE  
___




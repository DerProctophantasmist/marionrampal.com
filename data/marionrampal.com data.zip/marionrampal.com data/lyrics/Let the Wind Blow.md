#### Let the Wind Blow

Lord Lord  
Here’s a lonely sound  
Lord  
Here’s a lonely sound  
Lord  
While I walk my ground  
Lord Lord  
Tell me ‘bout the wind  
Lord  
Whisper ‘bout the wind  
Lord  
Where it’s heading at  
For we’re wild as it is  
We’re free as it is  
We come as it comes   
And we go as it goes  
Once we’ve learned   
To simply sit there  
Moaning  
Knowing that the Wind blows everywhere  


Let the Wind blow everywhere  
Let the Wind blow   
Let the Wind blow everywhere  


Fathers  
Mothers  
Sons and  
Daughters
Cling to the good word  
Cling to the good word  
For the Wind tells about the sweet things  
And it tells about the terrible ones  
The Wind was there long before  
Our skins could ever feel its kisses  
The Wind is a blind and silent witness  
And it blows ‘round the soul  
It blows there and everywhere  


Lord Lord  
Let it blow  
Let it go wild or whisper low  
Lord Lord  
Let it blow  
That is all we’ll ever know  
____
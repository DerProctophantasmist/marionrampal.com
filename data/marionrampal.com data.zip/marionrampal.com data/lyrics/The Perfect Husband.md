#### The Perfect Husband

Some gipsy spell  
Marked on my palm  
It says I’ll always have to roam  
But I still hold the ring of fire  
In which it burns for you and I  
And I waited days  
I waited nights  
I waited years for you to say  
Something about it  
Now what about it  
Looked for the you I knew  
But he was nowhere to be found  
Nowhere to be found  
He was nowhere to be found  
And I thought…  


…One day  
I might have to make a choice  
One day  
I might have to pack this suitcase of mine  
And go to where the snow  
Never threatens to fall  
Yeah go to where we all belong  


And oh I cried  
And oh I sang  
I thought it was for real  
One ticket to a dead end split  
When my wind blew  
I went with him  
I’ll be the East  
I’ll be the Sun  
I’ll be your Juliet on the run  
And oh I’ll weep  
I’ll weep for sure  
But I’ll leave no crumbs  
You’ll see that I’ll be nowhere to be found  
Nowhere to be found  
I’ll be nowhere to be found  
And you’ll float…  


…and one day  
You might have to make a choice  
One day  
You might have to pack this suitcase of yours  
And go to where the snow  
Never threatens to fall  
Yeah go to where we all belong  


Nowhere to be found  
(You’re gonna have to look for me baby)  
Nowhere to be found  
(I’m gonna be gone soon)  
Nowhere to be found  
(Back to where it all begins)  
Nowhere to be found  
(Back to where the sun never hides)  
Nowhere to be found  
(and if I run you run)  
Nowhere to be found   
(And if I roam you roam)  
Nowhere to be found  
(where were you)  
Nowhere to be found  
(When I needed you?)  
Nowhere to be found  
___


#### Go for It

What you see  
Into the night  
Is but the shadow of your life  
What you fear   
Is not outside  
It’s haunting your soul  
And flooding your mind  
You can panic  
You can shout  
But you can’t run away before the tide  
You can freak out  
You can call for help  
But there’s no get away   
There’s nowhere to hide  
You gotta…  


I know when  
I know why  
I know how things got all locked up inside  
You look for mirrors  
You look for signs  
Look out for new webs to tangle up your mind  
But watch out for the old refrain  
Cause gravity is coming soon   
It’s gonna get you there  
So do your thing   
It’s now or never  
You gotta understand   
The only way it’ll ever work is when you move to stand  


You gotta  
Go for it  
Go for it  
Go now  
Cause I’m done I’m gone  
I’m through with talking  
Go for it  
Go for it  
Go now  
Cause I’m done I’m gone  
I’m through with talking bout it  


So you go down and you go blind  
It’s coming to get you  
From all sides  
It’s starting to shake you up  
It’s getting wild  
The beat is pushing/ beat is pulsing/ beat is beating up your heart  
You’ll still fear  
You’ll still moan  
You’ll still forget you’ve ever heard that song   
Happy to fall down 
Or glad to lose it all  
Still you’ll do things you’ve never done before  
And you will   


Go for it  
Go for it  
Go now  
Cause I’m done I’m gone  
I’m through with talking  
Go for it  
Go for it  
Go now    
Cause I’m done I’m gone  
I’m through with talking bout it  
_____
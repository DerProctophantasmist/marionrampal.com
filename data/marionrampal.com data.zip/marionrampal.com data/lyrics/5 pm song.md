#### 5PM Song

Low was the tide  
Oh but high was the sun  
Towering up under heaven  
I took a turn on the merry-go-round  
Though I acted as if it was over  

Low sank the sun  
And up rose the tide  
I heard a theme in the air  
Then every clock stopped   
For a delicious while  
And it went back to spinning for ever  
It was there  
Coming on  
In a rather good tone  

Whoever comes to this  
Knows it’s not his to keep  
Songs are the wishes  
You dare make out loud   

So what shall I do  
With this beautiful lie?  
Am I the mold or the maker?  
You can sit with the muse  
But don’t look in her eye  
As you gather the whispers that matter  
Nothing less  
And nothing more  
Than what it takes to grow a song   

Whoever’s given this  
Knows it’s not his to keep  
Songs are the wishes  
You dare make out loud  
___


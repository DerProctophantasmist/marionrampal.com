#### À la mer

Sur mon bateau ma belle  
J’ai traversé les océans  
Sur mon bateau ma belle  
J’ai navigué par tous les temps  
Il m’a bien fait soleil dessus  
Il m’a bien plu  
Il m’a bien plu  


Si l’onde est calme ma belle  
J’irai chercher de beaux présents  
À hurler “Terre!” ma belle  
Me reste l’ombre sous le chant  
Le temps salant m’a fait si vieux  
Tout change autour en pas bien mieux  


Longtemps rêvé, beaucoup pleuré  
Le goût du Pays d’Avant  
Quitté à l’age de pas-bien-vieux pour l’Enfer  
Et si mon cœur voit le printemps  
Au bord de l’eau toi tu m’attends  
T’en vas chanter joli pour sauver mon âme  
 
Au fil de l’eau ma belle  
J’ai traversé tout l’océan  
Allant venant ma belle  
Toujours bravant le ciel méchant  
Le temps coulant s’est fait si lent  
Suis arrivé les pieds devant  


Et si mon âme voit le printemps  
Au bord de l’eau toi tu m’attends. 
___
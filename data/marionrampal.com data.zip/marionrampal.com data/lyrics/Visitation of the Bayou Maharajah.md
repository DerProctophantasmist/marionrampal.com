#### Visitation of the Bayou Maharajah 
*To James Booker*


Baby baby  
How everyone adores to be called Baby by&nbsp;you  
Baby baby 
At the crossroads of my dreams and&nbsp;fears 
I see you  
Where the lights turn low  
And we meet all the crawling creatures of&nbsp;the&nbsp;groove  
At this joint  
At the corner of this street and another and&nbsp;another  
Baby baby  
I heard that you've heard that she&nbsp;knew that you&nbsp;knew a guy who knew about the&nbsp;meaning of this BLUES  
it's YOUR THING THAT YOU DO  
baby   
And now you tell me:  
Is it worth a visit to the Big&nbsp;Family  
Or are we better off now  
Swimming in our own special&nbsp;sauce ?  
___

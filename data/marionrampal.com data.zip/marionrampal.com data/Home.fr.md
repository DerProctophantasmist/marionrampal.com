### Nouvel Album

### *SORTIE le 18 octobre 2019*
<div style="margin: 0" class="force-float-images-left clearfix ">
 ![youtube](https://www.youtube.com/watch?v=wbv88CRV3JI&list=PL5qp3t801Mh906POSR69Ta3-JcIs6YTe7)
__Marion RAMPAL: chant  
Pierre-François BLANCHARD: piano__  
*invitent*  
Archie SHEPP: saxophone ténor, chant  
Raúl BARBOZA: accordéon</div>
<a class="button text-center special-font h2 narrow" href="#lesecret.0" du-smooth-scroll>LE SECRET</a>